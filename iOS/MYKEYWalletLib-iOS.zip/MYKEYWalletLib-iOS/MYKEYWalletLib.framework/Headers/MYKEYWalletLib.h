//
//  MYKEYWalletLib.h
//  MYKEYWalletLib
//
//  Created by mykey-dev on 2019/7/2.
//  Copyright © 2019 MYKEYLab. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MYKEYWalletLib.
FOUNDATION_EXPORT double MYKEYWalletLibVersionNumber;

//! Project version string for MYKEYWalletLib.
FOUNDATION_EXPORT const unsigned char MYKEYWalletLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MYKEYWalletLib/PublicHeader.h>



